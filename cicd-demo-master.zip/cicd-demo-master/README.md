# cicd-demo

![Python application - tests](https://github.com/cn-dino/cicd-demo/workflows/Python%20application%20-%20tests/badge.svg)
